The supplemental .zip archive for this publication contains the following files. Stata files were created using Version 16.1 and may not be compatible with earlier versions. Please also note that users should change the working directory in the .do files when running those codes.

1. "data" folder stores the data used for the analyses
	EngMig.dta => Extracted data from articles included in this meta-analysis
	Fig_PubTrend_CliMig_Final.csv => Yearly numbers of publication from CliMig dataset
	Fig_PubTrend_OtherMeta => Yearly numbers of publication from other meta-analysis papers
	figure_3_mode.grec => Stata file that makes modification on color schemes to Figure 3

2. "results" folder stores results and log files
	figure_1.png, figure_3.png
	table_6.doc, table_a2.doc, table_a3.doc
	figures.log => Stata log file
	tables.log => Stata log file

3. Stata program file to produce figures
	figures.do

4. Stata program file to product tables. Please note manual editing is needed to make the final tables in the paper
	tables.do

