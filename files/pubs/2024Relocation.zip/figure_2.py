#======================================================================================
# load libraries
#======================================================================================
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

#======================================================================================
# read data
#======================================================================================
world = gpd.read_file('./data/ne_10m_admin_1_states_provinces.zip')
china = world[world['iso_a2'].isin(['CN','HK','MO','TW'])]
china.crs

cda_temp = gpd.read_file('./data/ContiguousDestituteAreas.shp')
cda_temp = cda_temp.to_crs(crs=china.crs)
cda_temp.crs
cda_temp['diss_col'] = 0
cda_dissolve = cda_temp.dissolve(by='diss_col')

#======================================================================================
# clip CDA and select provinces and counties
#======================================================================================
cda = gpd.clip(cda_dissolve, china)
province = china[china['name'].isin(['Gansu','Shaanxi','Sichuan','Yunnan','Guizhou','Guangxi','Hunan','Hubei'])]
province.crs

county = gpd.read_file('./data/24County.shp')
county = county.to_crs(crs=china.crs)
county.crs

#======================================================================================
# plot
#======================================================================================
fig, ax = plt.subplots(1,figsize=(12,12))
china.plot(ax=ax,alpha=1,edgecolor='black',facecolor="none",lw=0.5)
cda.plot(ax=ax,alpha=0.5,facecolor="none",color='grey',edgecolor='none',lw=0.5)
province.plot(ax=ax,alpha=1,facecolor='none',hatch='////\\\\',edgecolor='black',lw=1.5)
county.plot(ax=ax,color='black',alpha=1,legend=True)

legendelement = [
mpatches.Patch(color='black',label='County'),
mpatches.Patch(facecolor='white',hatch='////\\\\',label='Province'),
mpatches.Patch(color='grey',alpha=0.4,label='CDA')
]
ax.legend(handles=legendelement,loc='lower left',fontsize='22')
ax.axis('off')
plt.savefig('./results/figure_2.png', bbox_inches='tight', dpi=600)

#======================================================================================
# END
#======================================================================================

