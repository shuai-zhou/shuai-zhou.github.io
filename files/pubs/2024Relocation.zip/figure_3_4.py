#======================================================================================
# load libraries
#======================================================================================
import numpy as np
import pandas as pd
import seaborn as sns
from PIL import Image
import matplotlib.pyplot as plt

#======================================================================================
# 2016
#======================================================================================
df16 = pd.read_stata('./data/corr_2016_heatmap.dta')
fig, ax = plt.subplots(figsize=(16, 6))
xla = ['Household head age','Household head gender','Household head education','Household head marriage','Han people',
       'Household size','Household income (log)','Livestock values (log)','Landholding at the origin',
       'Running water at the origin','Electricity at the origin','Distance to paved road','Distance to local market',
       'Distance to elementary school','Distance to middle school','Distance to high school','Friends at the origin',
       'Visting times by officials']
ax = sns.heatmap(df16.corr(numeric_only=False).round(2),xticklabels=xla,yticklabels=xla,vmin=-1,vmax=1,annot=True,cmap='coolwarm')
fig.savefig('./results/corr2016.png', bbox_inches='tight', dpi=600)

#======================================================================================
# 2017 and 2019
#======================================================================================
df19 = pd.read_stata('./data/corr_2019_heatmap.dta')
fig, ax = plt.subplots(figsize=(16, 6))
xla = ['Household head age','Household head gender','Household head education','Household head marriage','Han people',
       'Household size','Household income (log)','Livestock values (log)','Landholding at the origin',
       'landholding at the destination','Left-behind members','Friends at the destination','Friends at the origin',
       'Apartment satisfaction','One-way commuting time','Relocation preference']
ax = sns.heatmap(df19.corr(numeric_only=False).round(2),xticklabels=xla,yticklabels=xla,vmin=-1,vmax=1,annot=True,cmap='coolwarm')
fig.savefig('./results/corr2019.png', bbox_inches='tight', dpi=600)

#======================================================================================
# color to gray
#======================================================================================
f2016 = './results/corr2016.png'
img2016 = Image.open(f2016).convert("L")
arr = np.asarray(img2016)
plt.figure(figsize=(16, 6))
plt.imshow(arr, cmap='gray', vmin=0, vmax=255)
plt.axis("off")
plt.savefig('./results/corr2016_gray.png', dpi=800, bbox_inches='tight')

f2019 = './results/corr2019.png'
img2019 = Image.open(f2019).convert("L")
arr = np.asarray(img2019)
plt.figure(figsize=(16, 6))
plt.imshow(arr, cmap='gray', vmin=0, vmax=255)
plt.axis("off")
plt.savefig('./results/corr2019_gray.png', dpi=800, bbox_inches='tight')

#======================================================================================
# END
#======================================================================================

